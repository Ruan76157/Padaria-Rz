package com.javaRz.padaria.infra;

public interface SecurityConfig {
}
