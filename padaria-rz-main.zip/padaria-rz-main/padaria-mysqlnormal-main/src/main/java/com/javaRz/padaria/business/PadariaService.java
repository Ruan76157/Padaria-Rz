package com.javaRz.padaria.business;

import com.javaRz.padaria.infrastructure.entitys.Padaria;
import com.javaRz.padaria.infrastructure.repository.PadariaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PadariaService {

    private final PadariaRepository padariaRepository;

    public void salvarPadaria(Padaria padaria) {
        padariaRepository.save(padaria);
    }

    public Padaria buscarPorId(Integer id) {
        return padariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item de padaria não encontrado com Id: " + id));
    }

    public List<Padaria> listarTodos() {
        return padariaRepository.findAll();
    }

    public void atualizarPadaria(Integer id, Padaria novaPadaria) {
        Padaria existente = padariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item de padaria não encontrado com Id: " + id));

        existente.setNome(novaPadaria.getNome());
        existente.setPreco(novaPadaria.getPreco());
        existente.setQuantidade(novaPadaria.getQuantidade());
        existente.setDescricao(novaPadaria.getDescricao());
        existente.setCategoria(novaPadaria.getCategoria());

        padariaRepository.save(existente);
    }

    public void deletarPadaria(Integer id) {
        if (!padariaRepository.existsById(id)) {
            throw new RuntimeException("Item de padaria não encontrado com Id: " + id);
        }
        padariaRepository.deleteById(id);
    }

    // Ajuste rápido de estoque
    public void ajustarEstoque(Integer id, int quantidade) {
        Padaria produto = padariaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado com id: " + id));

        int novoEstoque = produto.getQuantidade() + quantidade;
        if (novoEstoque < 0) novoEstoque = 0;

        produto.setQuantidade(novoEstoque);
        padariaRepository.save(produto);
    }
}
