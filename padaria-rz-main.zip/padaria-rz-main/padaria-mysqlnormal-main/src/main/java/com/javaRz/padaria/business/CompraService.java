package com.javaRz.padaria.business;

import com.javaRz.padaria.dto.CompraRequestDTO;
import com.javaRz.padaria.infrastructure.entitys.Compra;
import com.javaRz.padaria.infrastructure.entitys.Padaria;
import com.javaRz.padaria.infrastructure.entitys.Usuario;
import com.javaRz.padaria.infrastructure.repository.CompraRepository;
import com.javaRz.padaria.infrastructure.repository.PadariaRepository;
import com.javaRz.padaria.infrastructure.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CompraService {

    private final CompraRepository compraRepository;
    private final UsuarioRepository usuarioRepository;
    private final PadariaRepository padariaRepository;

    public Compra criarCompraComDTO(CompraRequestDTO dto) {
        log.info("=== INICIANDO CRIAÇÃO DE COMPRA ===");
        log.info("DTO recebido - usuarioId: {}, produtosIds: {}, valorTotal: {}",
                dto.getUsuarioId(), dto.getProdutosIds(), dto.getValorTotal());

        // Buscar usuário
        Usuario usuario = usuarioRepository.findById(dto.getUsuarioId())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + dto.getUsuarioId()));

        log.info("Usuário encontrado: {}", usuario.getNome());

        // Buscar produtos
        List<Padaria> produtos = padariaRepository.findAllById(dto.getProdutosIds());
        log.info("Produtos encontrados: {}", produtos.size());

        if (produtos.isEmpty()) {
            throw new RuntimeException("Nenhum produto encontrado");
        }

        // Calcular valor total
        Double valorTotal = dto.getValorTotal();
        if (valorTotal == null || valorTotal == 0) {
            valorTotal = produtos.stream()
                    .mapToDouble(p -> p.getPreco() != null ? p.getPreco() : 0.0)
                    .sum();
        }
        log.info("Valor total: {}", valorTotal);

        // GERAR ID AUTOMATICAMENTE
        Integer proximoId = compraRepository.findAll().stream()
                .map(Compra::getId)
                .filter(id -> id != null)
                .max(Integer::compareTo)
                .orElse(0) + 1;

        log.info("ID gerado automaticamente: {}", proximoId);

        // Criar compra COM ID
        Compra compra = Compra.builder()
                .id(proximoId)  // <<<< ISSO É CRUCIAL
                .usuario(usuario)
                .produtos(produtos)
                .valorTotal(valorTotal)
                .dataCompra(LocalDateTime.now())
                .build();

        log.info("Salvando compra com ID: {}", compra.getId());
        Compra compraSalva = compraRepository.save(compra);
        log.info("Compra salva com sucesso! ID: {}", compraSalva.getId());

        return compraSalva;
    }

    public List<Compra> listarTodas() {
        return compraRepository.findAll();
    }

    public Compra buscarPorId(Integer id) {
        return compraRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Compra não encontrada"));
    }

    public List<Compra> buscarPorUsuarioCpf(Integer usuarioId) {
        return compraRepository.findByUsuarioId(usuarioId);
    }

    public void deletarCompra(Integer id) {
        if (!compraRepository.existsById(id)) {
            throw new RuntimeException("Compra não encontrada");
        }
        compraRepository.deleteById(id);
    }
}