package com.javaRz.padaria.infrastructure.repository;

import com.javaRz.padaria.infrastructure.entitys.Compra;
import com.javaRz.padaria.infrastructure.entitys.Usuario;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CompraRepository extends MongoRepository<Compra, Integer> {
    List<Compra> findByUsuario(Usuario usuario);

    List<Compra> findByUsuarioId(Integer usuarioId);
}
