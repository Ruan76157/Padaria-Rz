package com.javaRz.padaria.Controller;

import com.javaRz.padaria.infrastructure.entitys.Compra;
import com.javaRz.padaria.dto.CompraRequestDTO;
import com.javaRz.padaria.business.CompraService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j  // <- Adicione isso
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/compras")
@RequiredArgsConstructor
public class CompraController {

    private final CompraService compraService;

    @PostMapping
    public ResponseEntity<?> criarCompra(@RequestBody CompraRequestDTO dto) {
        try {
            log.info("Recebendo requisição para criar compra: {}", dto);
            Compra novaCompra = compraService.criarCompraComDTO(dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(novaCompra);
        } catch (RuntimeException e) {
            log.error("Erro ao criar compra: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping
    public ResponseEntity<List<Compra>> listarTodas() {
        List<Compra> compras = compraService.listarTodas();
        return ResponseEntity.ok(compras);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Integer id) {
        try {
            Compra compra = compraService.buscarPorId(id);
            return ResponseEntity.ok(compra);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<Compra>> buscarPorUsuario(@PathVariable Integer usuarioId) {
        List<Compra> compras = compraService.buscarPorUsuarioCpf(usuarioId);
        return ResponseEntity.ok(compras);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Integer id) {
        try {
            compraService.deletarCompra(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }
}