package com.javaRz.padaria.dto;

import lombok.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CompraRequestDTO {
    private Integer usuarioId;          // ID do usuário
    private List<Integer> produtosIds;  // IDs dos produtos
    private Double valorTotal;          // Valor total (opcional)

    // Método para compatibilidade (se necessário)
    public String getUsuarioCpf() {
        return String.valueOf(usuarioId);
    }
}