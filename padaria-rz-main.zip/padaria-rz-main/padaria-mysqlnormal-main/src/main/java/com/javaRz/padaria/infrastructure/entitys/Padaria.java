package com.javaRz.padaria.infrastructure.entitys;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "padarias")
public class Padaria {

        @Id
        private Integer id;

        private String nome;
        private Double preco;
        private Integer quantidade;
        private String descricao;
        private String categoria;
}
