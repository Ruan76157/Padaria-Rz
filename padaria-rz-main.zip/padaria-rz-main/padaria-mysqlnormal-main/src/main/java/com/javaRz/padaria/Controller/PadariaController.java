package com.javaRz.padaria.Controller;

import com.javaRz.padaria.infrastructure.entitys.Padaria;
import com.javaRz.padaria.business.PadariaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/padaria")
@RequiredArgsConstructor
public class PadariaController {

    private final PadariaService padariaService;

    @PostMapping
    public ResponseEntity<Void> salvarPadaria(@RequestBody Padaria padaria) {
        padariaService.salvarPadaria(padaria);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Padaria> buscarPorId(@PathVariable Integer id) {
        Padaria padaria = padariaService.buscarPorId(id);
        return ResponseEntity.ok(padaria);
    }

    @GetMapping
    public ResponseEntity<List<Padaria>> listarTodos() {
        return ResponseEntity.ok(padariaService.listarTodos());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> atualizarPadaria(@PathVariable Integer id, @RequestBody Padaria padaria) {
        padariaService.atualizarPadaria(id, padaria);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarProduto(@PathVariable Integer id) {
        padariaService.deletarPadaria(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ NOVO: ajuste de estoque direto via botão +1/-1/+10
    @PutMapping("/{id}/ajustar-estoque")
    public ResponseEntity<Void> ajustarEstoque(@PathVariable Integer id, @RequestParam int quantidade) {
        padariaService.ajustarEstoque(id, quantidade);
        return ResponseEntity.noContent().build();
    }
}
