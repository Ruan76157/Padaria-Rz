package com.javaRz.padaria.dto;

import com.javaRz.padaria.infrastructure.role.UserRole;

public record RegisterDTO(
        String login,
        String password,
        UserRole role) {
}
