package com.javaRz.padaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PadariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
