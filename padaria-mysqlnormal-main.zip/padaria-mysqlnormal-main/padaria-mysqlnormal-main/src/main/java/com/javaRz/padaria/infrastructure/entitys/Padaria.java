package com.javaRz.padaria.infrastructure.entitys;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "tb_padaria")
public class Padaria {


        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;

        @Column(name = "nome")
        private String nome;

        @Column(name = "preco")
        private Double preco;

        @Column(name = "quantidade")
        private Integer quantidade;

        // ADICIONE ESTES CAMPOS:
        @Column(name = "descricao")
        private String descricao;

        @Column(name = "categoria")
        private String categoria;

}