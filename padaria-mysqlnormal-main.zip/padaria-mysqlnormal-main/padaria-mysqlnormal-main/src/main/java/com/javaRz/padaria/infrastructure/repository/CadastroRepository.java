package com.javaRz.padaria.infrastructure.repository;
import com.javaRz.padaria.infrastructure.entitys.Cadastro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CadastroRepository extends JpaRepository< Cadastro,Long> {
}
