package com.javaRz.padaria.infrastructure.repository;
import com.javaRz.padaria.infrastructure.entitys.Padaria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PadariaRepository extends JpaRepository<Padaria, Long> {

}