package com.javaRz.padaria.business;

import com.javaRz.padaria.infrastructure.entitys.Compra;
import com.javaRz.padaria.infrastructure.entitys.Padaria;
import com.javaRz.padaria.infrastructure.entitys.Usuario;
import com.javaRz.padaria.infrastructure.repository.CompraRepository;
import com.javaRz.padaria.infrastructure.repository.PadariaRepository;
import com.javaRz.padaria.infrastructure.repository.UsuarioRepository;
import com.javaRz.padaria.dto.CompraRequestDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // 👈 importante para rollback automático

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CompraService {

    private final CompraRepository compraRepository;
    private final UsuarioRepository usuarioRepository;
    private final PadariaRepository padariaRepository;

    /**
     * Cria uma nova compra e diminui a quantidade (estoque) dos produtos comprados.
     */
    @Transactional
    public Compra criarCompraComDTO(CompraRequestDTO dto) {
        // Busca o usuário pelo ID fornecido
        Usuario usuario = usuarioRepository.findById(Math.toIntExact(dto.getUsuarioId().longValue()))
                .orElseThrow(() -> new RuntimeException("Usuário com ID " + dto.getUsuarioId() + " não encontrado."));

        // Busca os produtos (padarias) pelos IDs fornecidos
        List<Padaria> produtos = padariaRepository.findAllById(dto.getProdutosIds());
        if (produtos.isEmpty()) {
            throw new RuntimeException("Nenhum produto encontrado com os IDs fornecidos.");
        }

        // 🔽 Diminui a quantidade (estoque) dos produtos comprados
        for (Padaria produto : produtos) {
            if (produto.getQuantidade() == null) {
                throw new RuntimeException("Produto '" + produto.getNome() + "' não possui campo de quantidade definido.");
            }

            // Verifica se há quantidade suficiente
            if (produto.getQuantidade() < dto.getQuantidade()) {
                throw new RuntimeException("Estoque insuficiente para o produto: " + produto.getNome());
            }

            // Diminui a quantidade disponível
            produto.setQuantidade(produto.getQuantidade() - dto.getQuantidade());

            // Salva o produto atualizado
            padariaRepository.save(produto);
        }

        // Cria a compra com os dados atualizados
        Compra compra = Compra.builder()
                .usuario(usuario)
                .produtos(produtos)
                .dataCompra(LocalDateTime.now())
                .valorTotal(calcularValorTotal(produtos, dto.getQuantidade()))
                .build();

        return compraRepository.save(compra);
    }

    /**
     * Calcula o valor total da compra (preço dos produtos * quantidade).
     */
    private Double calcularValorTotal(List<Padaria> produtos, Integer quantidade) {
        return produtos.stream()
                .mapToDouble(p -> (p.getPreco() != null ? p.getPreco() : 0.0) * quantidade)
                .sum();
    }
}
