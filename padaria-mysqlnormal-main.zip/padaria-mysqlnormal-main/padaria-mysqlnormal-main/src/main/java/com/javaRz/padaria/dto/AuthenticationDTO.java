package com.javaRz.padaria.dto;

public record AuthenticationDTO(String login, String password) {
}
